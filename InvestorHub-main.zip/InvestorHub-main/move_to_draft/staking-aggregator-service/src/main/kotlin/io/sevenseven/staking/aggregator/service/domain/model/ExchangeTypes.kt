package io.sevenseven.staking.aggregator.service.domain.model


enum class ExchangeTypes {

    UNISWAP

}
