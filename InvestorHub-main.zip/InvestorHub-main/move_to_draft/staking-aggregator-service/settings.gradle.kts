rootProject.name = "staking-aggregator-service"
